
print('بوت Goooooood114')
